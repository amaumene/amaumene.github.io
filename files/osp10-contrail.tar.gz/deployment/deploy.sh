source ~/stackrc
templates="/home/stack/my_contrail_templates"
openstack overcloud deploy --templates $templates \
  -r $templates/environments/contrail/roles_data.yaml \
  -e $templates/environments/contrail/contrail-services.yaml \
  -e $(pwd)/network-isolation.yaml \
  -e $templates/environments/contrail/contrail-net.yaml \
  -e $(pwd)/custom.yaml \
  --timeout 180 
  
