source ~/stackrc
openstack overcloud deploy --templates /home/stack/templates \
  -r $(pwd)/roles_data_hci.yaml \
  -e $(pwd)/network-isolation.yaml \
  -e $(pwd)/storage-environment.yaml \
  -e $(pwd)/network-environment.yaml \
  --ntp-server pool.ntp.org \
  --timeout 180 
