openstack overcloud deploy --templates /home/stack/my_templates \
-r $(pwd)/roles_data.yaml \
-n $(pwd)/network_data.yaml \
-e $(pwd)/../my_templates/environments/network-isolation.yaml \
-e $(pwd)/overcloud_images.yaml \
-e $(pwd)/environment.yaml \
-e $(pwd)/storage-environment.yaml
